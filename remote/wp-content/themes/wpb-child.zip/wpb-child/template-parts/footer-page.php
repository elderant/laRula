<?php if(!is_single()) :?>
	<footer class="entry-footer">
<?php endif;?>
	<div class="row column-footer justify-content-center align-content-center">
		<div class="first-column col-lg-4 col-md-4 col-sm-12">
			<img src="http://localhost/larula/wp-content/uploads/2019/03/page-logo.png" alt="La rula taller">
		</div>
		<div class="second-column col-lg-4 col-md-4 col-sm-12">
			Some content here
		</div>
		<div class="third-column col-lg-4 col-md-4 col-sm-12">
			Someother content here
		</div>
	</div>
<?php if(!is_single()) :?>
</footer>
<?php endif;?>